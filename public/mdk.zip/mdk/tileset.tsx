<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="mith" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="tilemap.png" width="256" height="256"/>
</tileset>
